(function(react) {

//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp = Object.defineProperty;
	var __name = (target, value) => __defProp(target, "name", {
		value,
		configurable: true
	});
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) {
			__defProp(target, name, {
				get: all[name],
				enumerable: true
			});
		}
		if (!no_symbols) {
			__defProp(target, Symbol.toStringTag, { value: "Module" });
		}
		return target;
	};
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") {
			for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
				key = keys[i];
				if (!__hasOwnProp.call(to, key) && key !== except) {
					__defProp(to, key, {
						get: ((k) => from[k]).bind(null, key),
						enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
					});
				}
			}
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));

//#endregion
react = __toESM(react, 1);

//#region node_modules/@tanstack/query-core/build/modern/subscribable.js
	var Subscribable = class {
		constructor() {
			this.listeners = /* @__PURE__ */ new Set();
			this.subscribe = this.subscribe.bind(this);
		}
		subscribe(listener) {
			this.listeners.add(listener);
			this.onSubscribe();
			return () => {
				this.listeners.delete(listener);
				this.onUnsubscribe();
			};
		}
		hasListeners() {
			return this.listeners.size > 0;
		}
		onSubscribe() {}
		onUnsubscribe() {}
	};

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/timeoutManager.js
	var defaultTimeoutProvider = {
		setTimeout: (callback, delay) => setTimeout(callback, delay),
		clearTimeout: (timeoutId) => clearTimeout(timeoutId),
		setInterval: (callback, delay) => setInterval(callback, delay),
		clearInterval: (intervalId) => clearInterval(intervalId)
	};
	var TimeoutManager = class {
		#provider = defaultTimeoutProvider;
		#providerCalled = false;
		setTimeoutProvider(provider) {
			if (this.#providerCalled && provider !== this.#provider) console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
				previous: this.#provider,
				provider
			});
			this.#provider = provider;
			this.#providerCalled = false;
		}
		setTimeout(callback, delay) {
			this.#providerCalled = true;
			return this.#provider.setTimeout(callback, delay);
		}
		clearTimeout(timeoutId) {
			this.#provider.clearTimeout(timeoutId);
		}
		setInterval(callback, delay) {
			this.#providerCalled = true;
			return this.#provider.setInterval(callback, delay);
		}
		clearInterval(intervalId) {
			this.#provider.clearInterval(intervalId);
		}
	};
	var timeoutManager = new TimeoutManager();
	function systemSetTimeoutZero(callback) {
		setTimeout(callback, 0);
	}

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/utils.js
	var isServer = typeof window === "undefined" || "Deno" in globalThis;
	function noop() {}
	function functionalUpdate(updater, input) {
		return typeof updater === "function" ? updater(input) : updater;
	}
	function isValidTimeout(value) {
		return typeof value === "number" && value >= 0 && value !== Infinity;
	}
	function timeUntilStale(updatedAt, staleTime) {
		return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
	}
	function resolveStaleTime(staleTime, query) {
		return typeof staleTime === "function" ? staleTime(query) : staleTime;
	}
	function resolveEnabled(enabled, query) {
		return typeof enabled === "function" ? enabled(query) : enabled;
	}
	function matchQuery(filters, query) {
		const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
		if (queryKey) {
			if (exact) {
				if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
			} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
		}
		if (type !== "all") {
			const isActive = query.isActive();
			if (type === "active" && !isActive) return false;
			if (type === "inactive" && isActive) return false;
		}
		if (typeof stale === "boolean" && query.isStale() !== stale) return false;
		if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
		if (predicate && !predicate(query)) return false;
		return true;
	}
	function matchMutation(filters, mutation) {
		const { exact, status, predicate, mutationKey } = filters;
		if (mutationKey) {
			if (!mutation.options.mutationKey) return false;
			if (exact) {
				if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
			} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
		}
		if (status && mutation.state.status !== status) return false;
		if (predicate && !predicate(mutation)) return false;
		return true;
	}
	function hashQueryKeyByOptions(queryKey, options) {
		return (options?.queryKeyHashFn || hashKey)(queryKey);
	}
	function hashKey(queryKey) {
		return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
			result[key] = val[key];
			return result;
		}, {}) : val);
	}
	function partialMatchKey(a, b) {
		if (a === b) return true;
		if (typeof a !== typeof b) return false;
		if (a && b && typeof a === "object" && typeof b === "object") return Object.keys(b).every((key) => partialMatchKey(a[key], b[key]));
		return false;
	}
	var hasOwn = Object.prototype.hasOwnProperty;
	function replaceEqualDeep(a, b) {
		if (a === b) return a;
		const array = isPlainArray(a) && isPlainArray(b);
		if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
		const aSize = (array ? a : Object.keys(a)).length;
		const bItems = array ? b : Object.keys(b);
		const bSize = bItems.length;
		const copy = array ? new Array(bSize) : {};
		let equalItems = 0;
		for (let i = 0; i < bSize; i++) {
			const key = array ? i : bItems[i];
			const aItem = a[key];
			const bItem = b[key];
			if (aItem === bItem) {
				copy[key] = aItem;
				if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
				continue;
			}
			if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
				copy[key] = bItem;
				continue;
			}
			const v = replaceEqualDeep(aItem, bItem);
			copy[key] = v;
			if (v === aItem) equalItems++;
		}
		return aSize === bSize && equalItems === aSize ? a : copy;
	}
	function shallowEqualObjects(a, b) {
		if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
		for (const key in a) if (a[key] !== b[key]) return false;
		return true;
	}
	function isPlainArray(value) {
		return Array.isArray(value) && value.length === Object.keys(value).length;
	}
	function isPlainObject(o) {
		if (!hasObjectPrototype(o)) return false;
		const ctor = o.constructor;
		if (ctor === void 0) return true;
		const prot = ctor.prototype;
		if (!hasObjectPrototype(prot)) return false;
		if (!prot.hasOwnProperty("isPrototypeOf")) return false;
		if (Object.getPrototypeOf(o) !== Object.prototype) return false;
		return true;
	}
	function hasObjectPrototype(o) {
		return Object.prototype.toString.call(o) === "[object Object]";
	}
	function sleep(timeout) {
		return new Promise((resolve) => {
			timeoutManager.setTimeout(resolve, timeout);
		});
	}
	function replaceData(prevData, data, options) {
		if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
		else if (options.structuralSharing !== false) try {
			return replaceEqualDeep(prevData, data);
		} catch (error) {
			console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
			throw error;
		}
		return data;
	}
	function addToEnd(items, item, max = 0) {
		const newItems = [...items, item];
		return max && newItems.length > max ? newItems.slice(1) : newItems;
	}
	function addToStart(items, item, max = 0) {
		const newItems = [item, ...items];
		return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
	}
	var skipToken = Symbol();
	function ensureQueryFn(options, fetchOptions) {
		if (options.queryFn === skipToken) console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
		if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
		if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
		return options.queryFn;
	}
	function shouldThrowError(throwOnError, params) {
		if (typeof throwOnError === "function") return throwOnError(...params);
		return !!throwOnError;
	}
	function addConsumeAwareSignal(object, getSignal, onCancelled) {
		let consumed = false;
		let signal;
		Object.defineProperty(object, "signal", {
			enumerable: true,
			get: () => {
				signal ??= getSignal();
				if (consumed) return signal;
				consumed = true;
				if (signal.aborted) onCancelled();
				else signal.addEventListener("abort", onCancelled, { once: true });
				return signal;
			}
		});
		return object;
	}

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/focusManager.js
	var FocusManager = class extends Subscribable {
		#focused;
		#cleanup;
		#setup;
		constructor() {
			super();
			this.#setup = (onFocus) => {
				if (!isServer && window.addEventListener) {
					const listener = () => onFocus();
					window.addEventListener("visibilitychange", listener, false);
					return () => {
						window.removeEventListener("visibilitychange", listener);
					};
				}
			};
		}
		onSubscribe() {
			if (!this.#cleanup) this.setEventListener(this.#setup);
		}
		onUnsubscribe() {
			if (!this.hasListeners()) {
				this.#cleanup?.();
				this.#cleanup = void 0;
			}
		}
		setEventListener(setup) {
			this.#setup = setup;
			this.#cleanup?.();
			this.#cleanup = setup((focused) => {
				if (typeof focused === "boolean") this.setFocused(focused);
				else this.onFocus();
			});
		}
		setFocused(focused) {
			if (this.#focused !== focused) {
				this.#focused = focused;
				this.onFocus();
			}
		}
		onFocus() {
			const isFocused = this.isFocused();
			this.listeners.forEach((listener) => {
				listener(isFocused);
			});
		}
		isFocused() {
			if (typeof this.#focused === "boolean") return this.#focused;
			return globalThis.document?.visibilityState !== "hidden";
		}
	};
	var focusManager = new FocusManager();

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/thenable.js
	function pendingThenable() {
		let resolve;
		let reject;
		const thenable = new Promise((_resolve, _reject) => {
			resolve = _resolve;
			reject = _reject;
		});
		thenable.status = "pending";
		thenable.catch(() => {});
		function finalize(data) {
			Object.assign(thenable, data);
			delete thenable.resolve;
			delete thenable.reject;
		}
		thenable.resolve = (value) => {
			finalize({
				status: "fulfilled",
				value
			});
			resolve(value);
		};
		thenable.reject = (reason) => {
			finalize({
				status: "rejected",
				reason
			});
			reject(reason);
		};
		return thenable;
	}

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/notifyManager.js
	var defaultScheduler = systemSetTimeoutZero;
	function createNotifyManager() {
		let queue = [];
		let transactions = 0;
		let notifyFn = (callback) => {
			callback();
		};
		let batchNotifyFn = (callback) => {
			callback();
		};
		let scheduleFn = defaultScheduler;
		const schedule = (callback) => {
			if (transactions) queue.push(callback);
			else scheduleFn(() => {
				notifyFn(callback);
			});
		};
		const flush = () => {
			const originalQueue = queue;
			queue = [];
			if (originalQueue.length) scheduleFn(() => {
				batchNotifyFn(() => {
					originalQueue.forEach((callback) => {
						notifyFn(callback);
					});
				});
			});
		};
		return {
			batch: (callback) => {
				let result;
				transactions++;
				try {
					result = callback();
				} finally {
					transactions--;
					if (!transactions) flush();
				}
				return result;
			},
			/**
			* All calls to the wrapped function will be batched.
			*/
			batchCalls: (callback) => {
				return (...args) => {
					schedule(() => {
						callback(...args);
					});
				};
			},
			schedule,
			/**
			* Use this method to set a custom notify function.
			* This can be used to for example wrap notifications with `React.act` while running tests.
			*/
			setNotifyFunction: (fn) => {
				notifyFn = fn;
			},
			/**
			* Use this method to set a custom function to batch notifications together into a single tick.
			* By default React Query will use the batch function provided by ReactDOM or React Native.
			*/
			setBatchNotifyFunction: (fn) => {
				batchNotifyFn = fn;
			},
			setScheduler: (fn) => {
				scheduleFn = fn;
			}
		};
	}
	var notifyManager = createNotifyManager();

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/onlineManager.js
	var OnlineManager = class extends Subscribable {
		#online = true;
		#cleanup;
		#setup;
		constructor() {
			super();
			this.#setup = (onOnline) => {
				if (!isServer && window.addEventListener) {
					const onlineListener = () => onOnline(true);
					const offlineListener = () => onOnline(false);
					window.addEventListener("online", onlineListener, false);
					window.addEventListener("offline", offlineListener, false);
					return () => {
						window.removeEventListener("online", onlineListener);
						window.removeEventListener("offline", offlineListener);
					};
				}
			};
		}
		onSubscribe() {
			if (!this.#cleanup) this.setEventListener(this.#setup);
		}
		onUnsubscribe() {
			if (!this.hasListeners()) {
				this.#cleanup?.();
				this.#cleanup = void 0;
			}
		}
		setEventListener(setup) {
			this.#setup = setup;
			this.#cleanup?.();
			this.#cleanup = setup(this.setOnline.bind(this));
		}
		setOnline(online) {
			if (this.#online !== online) {
				this.#online = online;
				this.listeners.forEach((listener) => {
					listener(online);
				});
			}
		}
		isOnline() {
			return this.#online;
		}
	};
	var onlineManager = new OnlineManager();

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/retryer.js
	function defaultRetryDelay(failureCount) {
		return Math.min(1e3 * 2 ** failureCount, 3e4);
	}
	function canFetch(networkMode) {
		return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
	}
	var CancelledError = class extends Error {
		constructor(options) {
			super("CancelledError");
			this.revert = options?.revert;
			this.silent = options?.silent;
		}
	};
	function createRetryer(config) {
		let isRetryCancelled = false;
		let failureCount = 0;
		let continueFn;
		const thenable = pendingThenable();
		const isResolved = () => thenable.status !== "pending";
		const cancel = (cancelOptions) => {
			if (!isResolved()) {
				const error = new CancelledError(cancelOptions);
				reject(error);
				config.onCancel?.(error);
			}
		};
		const cancelRetry = () => {
			isRetryCancelled = true;
		};
		const continueRetry = () => {
			isRetryCancelled = false;
		};
		const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
		const canStart = () => canFetch(config.networkMode) && config.canRun();
		const resolve = (value) => {
			if (!isResolved()) {
				continueFn?.();
				thenable.resolve(value);
			}
		};
		const reject = (value) => {
			if (!isResolved()) {
				continueFn?.();
				thenable.reject(value);
			}
		};
		const pause = () => {
			return new Promise((continueResolve) => {
				continueFn = (value) => {
					if (isResolved() || canContinue()) continueResolve(value);
				};
				config.onPause?.();
			}).then(() => {
				continueFn = void 0;
				if (!isResolved()) config.onContinue?.();
			});
		};
		const run = () => {
			if (isResolved()) return;
			let promiseOrValue;
			const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
			try {
				promiseOrValue = initialPromise ?? config.fn();
			} catch (error) {
				promiseOrValue = Promise.reject(error);
			}
			Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
				if (isResolved()) return;
				const retry = config.retry ?? (isServer ? 0 : 3);
				const retryDelay = config.retryDelay ?? defaultRetryDelay;
				const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
				const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
				if (isRetryCancelled || !shouldRetry) {
					reject(error);
					return;
				}
				failureCount++;
				config.onFail?.(failureCount, error);
				sleep(delay).then(() => {
					return canContinue() ? void 0 : pause();
				}).then(() => {
					if (isRetryCancelled) reject(error);
					else run();
				});
			});
		};
		return {
			promise: thenable,
			status: () => thenable.status,
			cancel,
			continue: () => {
				continueFn?.();
				return thenable;
			},
			cancelRetry,
			continueRetry,
			canStart,
			start: () => {
				if (canStart()) run();
				else pause().then(run);
				return thenable;
			}
		};
	}

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/removable.js
	var Removable = class {
		#gcTimeout;
		destroy() {
			this.clearGcTimeout();
		}
		scheduleGc() {
			this.clearGcTimeout();
			if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
				this.optionalRemove();
			}, this.gcTime);
		}
		updateGcTime(newGcTime) {
			this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (isServer ? Infinity : 300 * 1e3));
		}
		clearGcTimeout() {
			if (this.#gcTimeout) {
				timeoutManager.clearTimeout(this.#gcTimeout);
				this.#gcTimeout = void 0;
			}
		}
	};

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/query.js
	var Query = class extends Removable {
		#initialState;
		#revertState;
		#cache;
		#client;
		#retryer;
		#defaultOptions;
		#abortSignalConsumed;
		constructor(config) {
			super();
			this.#abortSignalConsumed = false;
			this.#defaultOptions = config.defaultOptions;
			this.setOptions(config.options);
			this.observers = [];
			this.#client = config.client;
			this.#cache = this.#client.getQueryCache();
			this.queryKey = config.queryKey;
			this.queryHash = config.queryHash;
			this.#initialState = getDefaultState$1(this.options);
			this.state = config.state ?? this.#initialState;
			this.scheduleGc();
		}
		get meta() {
			return this.options.meta;
		}
		get promise() {
			return this.#retryer?.promise;
		}
		setOptions(options) {
			this.options = {
				...this.#defaultOptions,
				...options
			};
			this.updateGcTime(this.options.gcTime);
			if (this.state && this.state.data === void 0) {
				const defaultState = getDefaultState$1(this.options);
				if (defaultState.data !== void 0) {
					this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
					this.#initialState = defaultState;
				}
			}
		}
		optionalRemove() {
			if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
		}
		setData(newData, options) {
			const data = replaceData(this.state.data, newData, this.options);
			this.#dispatch({
				data,
				type: "success",
				dataUpdatedAt: options?.updatedAt,
				manual: options?.manual
			});
			return data;
		}
		setState(state, setStateOptions) {
			this.#dispatch({
				type: "setState",
				state,
				setStateOptions
			});
		}
		cancel(options) {
			const promise = this.#retryer?.promise;
			this.#retryer?.cancel(options);
			return promise ? promise.then(noop).catch(noop) : Promise.resolve();
		}
		destroy() {
			super.destroy();
			this.cancel({ silent: true });
		}
		reset() {
			this.destroy();
			this.setState(this.#initialState);
		}
		isActive() {
			return this.observers.some((observer) => resolveEnabled(observer.options.enabled, this) !== false);
		}
		isDisabled() {
			if (this.getObserversCount() > 0) return !this.isActive();
			return this.options.queryFn === skipToken || this.state.dataUpdateCount + this.state.errorUpdateCount === 0;
		}
		isStatic() {
			if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveStaleTime(observer.options.staleTime, this) === "static");
			return false;
		}
		isStale() {
			if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
			return this.state.data === void 0 || this.state.isInvalidated;
		}
		isStaleByTime(staleTime = 0) {
			if (this.state.data === void 0) return true;
			if (staleTime === "static") return false;
			if (this.state.isInvalidated) return true;
			return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
		}
		onFocus() {
			this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
			this.#retryer?.continue();
		}
		onOnline() {
			this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
			this.#retryer?.continue();
		}
		addObserver(observer) {
			if (!this.observers.includes(observer)) {
				this.observers.push(observer);
				this.clearGcTimeout();
				this.#cache.notify({
					type: "observerAdded",
					query: this,
					observer
				});
			}
		}
		removeObserver(observer) {
			if (this.observers.includes(observer)) {
				this.observers = this.observers.filter((x) => x !== observer);
				if (!this.observers.length) {
					if (this.#retryer) if (this.#abortSignalConsumed) this.#retryer.cancel({ revert: true });
					else this.#retryer.cancelRetry();
					this.scheduleGc();
				}
				this.#cache.notify({
					type: "observerRemoved",
					query: this,
					observer
				});
			}
		}
		getObserversCount() {
			return this.observers.length;
		}
		invalidate() {
			if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
		}
		async fetch(options, fetchOptions) {
			if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
				if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
				else if (this.#retryer) {
					this.#retryer.continueRetry();
					return this.#retryer.promise;
				}
			}
			if (options) this.setOptions(options);
			if (!this.options.queryFn) {
				const observer = this.observers.find((x) => x.options.queryFn);
				if (observer) this.setOptions(observer.options);
			}
			if (!Array.isArray(this.options.queryKey)) console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
			const abortController = new AbortController();
			const addSignalProperty = (object) => {
				Object.defineProperty(object, "signal", {
					enumerable: true,
					get: () => {
						this.#abortSignalConsumed = true;
						return abortController.signal;
					}
				});
			};
			const fetchFn = () => {
				const queryFn = ensureQueryFn(this.options, fetchOptions);
				const createQueryFnContext = () => {
					const queryFnContext2 = {
						client: this.#client,
						queryKey: this.queryKey,
						meta: this.meta
					};
					addSignalProperty(queryFnContext2);
					return queryFnContext2;
				};
				const queryFnContext = createQueryFnContext();
				this.#abortSignalConsumed = false;
				if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
				return queryFn(queryFnContext);
			};
			const createFetchContext = () => {
				const context2 = {
					fetchOptions,
					options: this.options,
					queryKey: this.queryKey,
					client: this.#client,
					state: this.state,
					fetchFn
				};
				addSignalProperty(context2);
				return context2;
			};
			const context = createFetchContext();
			this.options.behavior?.onFetch(context, this);
			this.#revertState = this.state;
			if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
				type: "fetch",
				meta: context.fetchOptions?.meta
			});
			this.#retryer = createRetryer({
				initialPromise: fetchOptions?.initialPromise,
				fn: context.fetchFn,
				onCancel: (error) => {
					if (error instanceof CancelledError && error.revert) this.setState({
						...this.#revertState,
						fetchStatus: "idle"
					});
					abortController.abort();
				},
				onFail: (failureCount, error) => {
					this.#dispatch({
						type: "failed",
						failureCount,
						error
					});
				},
				onPause: () => {
					this.#dispatch({ type: "pause" });
				},
				onContinue: () => {
					this.#dispatch({ type: "continue" });
				},
				retry: context.options.retry,
				retryDelay: context.options.retryDelay,
				networkMode: context.options.networkMode,
				canRun: () => true
			});
			try {
				const data = await this.#retryer.start();
				if (data === void 0) {
					console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
					throw new Error(`${this.queryHash} data is undefined`);
				}
				this.setData(data);
				this.#cache.config.onSuccess?.(data, this);
				this.#cache.config.onSettled?.(data, this.state.error, this);
				return data;
			} catch (error) {
				if (error instanceof CancelledError) {
					if (error.silent) return this.#retryer.promise;
					else if (error.revert) {
						if (this.state.data === void 0) throw error;
						return this.state.data;
					}
				}
				this.#dispatch({
					type: "error",
					error
				});
				this.#cache.config.onError?.(error, this);
				this.#cache.config.onSettled?.(this.state.data, error, this);
				throw error;
			} finally {
				this.scheduleGc();
			}
		}
		#dispatch(action) {
			const reducer = (state) => {
				switch (action.type) {
					case "failed": return {
						...state,
						fetchFailureCount: action.failureCount,
						fetchFailureReason: action.error
					};
					case "pause": return {
						...state,
						fetchStatus: "paused"
					};
					case "continue": return {
						...state,
						fetchStatus: "fetching"
					};
					case "fetch": return {
						...state,
						...fetchState(state.data, this.options),
						fetchMeta: action.meta ?? null
					};
					case "success":
						const newState = {
							...state,
							...successState(action.data, action.dataUpdatedAt),
							dataUpdateCount: state.dataUpdateCount + 1,
							...!action.manual && {
								fetchStatus: "idle",
								fetchFailureCount: 0,
								fetchFailureReason: null
							}
						};
						this.#revertState = action.manual ? newState : void 0;
						return newState;
					case "error":
						const error = action.error;
						return {
							...state,
							error,
							errorUpdateCount: state.errorUpdateCount + 1,
							errorUpdatedAt: Date.now(),
							fetchFailureCount: state.fetchFailureCount + 1,
							fetchFailureReason: error,
							fetchStatus: "idle",
							status: "error"
						};
					case "invalidate": return {
						...state,
						isInvalidated: true
					};
					case "setState": return {
						...state,
						...action.state
					};
				}
			};
			this.state = reducer(this.state);
			notifyManager.batch(() => {
				this.observers.forEach((observer) => {
					observer.onQueryUpdate();
				});
				this.#cache.notify({
					query: this,
					type: "updated",
					action
				});
			});
		}
	};
	function fetchState(data, options) {
		return {
			fetchFailureCount: 0,
			fetchFailureReason: null,
			fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
			...data === void 0 && {
				error: null,
				status: "pending"
			}
		};
	}
	function successState(data, dataUpdatedAt) {
		return {
			data,
			dataUpdatedAt: dataUpdatedAt ?? Date.now(),
			error: null,
			isInvalidated: false,
			status: "success"
		};
	}
	function getDefaultState$1(options) {
		const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
		const hasData = data !== void 0;
		const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
		return {
			data,
			dataUpdateCount: 0,
			dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
			error: null,
			errorUpdateCount: 0,
			errorUpdatedAt: 0,
			fetchFailureCount: 0,
			fetchFailureReason: null,
			fetchMeta: null,
			isInvalidated: false,
			status: hasData ? "success" : "pending",
			fetchStatus: "idle"
		};
	}
	__name(getDefaultState$1, "getDefaultState");

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryObserver.js
	var QueryObserver = class extends Subscribable {
		constructor(client, options) {
			super();
			this.options = options;
			this.#client = client;
			this.#selectError = null;
			this.#currentThenable = pendingThenable();
			this.bindMethods();
			this.setOptions(options);
		}
		#client;
		#currentQuery = void 0;
		#currentQueryInitialState = void 0;
		#currentResult = void 0;
		#currentResultState;
		#currentResultOptions;
		#currentThenable;
		#selectError;
		#selectFn;
		#selectResult;
		#lastQueryWithDefinedData;
		#staleTimeoutId;
		#refetchIntervalId;
		#currentRefetchInterval;
		#trackedProps = /* @__PURE__ */ new Set();
		bindMethods() {
			this.refetch = this.refetch.bind(this);
		}
		onSubscribe() {
			if (this.listeners.size === 1) {
				this.#currentQuery.addObserver(this);
				if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
				else this.updateResult();
				this.#updateTimers();
			}
		}
		onUnsubscribe() {
			if (!this.hasListeners()) this.destroy();
		}
		shouldFetchOnReconnect() {
			return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
		}
		shouldFetchOnWindowFocus() {
			return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
		}
		destroy() {
			this.listeners = /* @__PURE__ */ new Set();
			this.#clearStaleTimeout();
			this.#clearRefetchInterval();
			this.#currentQuery.removeObserver(this);
		}
		setOptions(options) {
			const prevOptions = this.options;
			const prevQuery = this.#currentQuery;
			this.options = this.#client.defaultQueryOptions(options);
			if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveEnabled(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
			this.#updateQuery();
			this.#currentQuery.setOptions(this.options);
			if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
				type: "observerOptionsUpdated",
				query: this.#currentQuery,
				observer: this
			});
			const mounted = this.hasListeners();
			if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
			this.updateResult();
			if (mounted && (this.#currentQuery !== prevQuery || resolveEnabled(this.options.enabled, this.#currentQuery) !== resolveEnabled(prevOptions.enabled, this.#currentQuery) || resolveStaleTime(this.options.staleTime, this.#currentQuery) !== resolveStaleTime(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
			const nextRefetchInterval = this.#computeRefetchInterval();
			if (mounted && (this.#currentQuery !== prevQuery || resolveEnabled(this.options.enabled, this.#currentQuery) !== resolveEnabled(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
		}
		getOptimisticResult(options) {
			const query = this.#client.getQueryCache().build(this.#client, options);
			const result = this.createResult(query, options);
			if (shouldAssignObserverCurrentProperties(this, result)) {
				this.#currentResult = result;
				this.#currentResultOptions = this.options;
				this.#currentResultState = this.#currentQuery.state;
			}
			return result;
		}
		getCurrentResult() {
			return this.#currentResult;
		}
		trackResult(result, onPropTracked) {
			return new Proxy(result, { get: (target, key) => {
				this.trackProp(key);
				onPropTracked?.(key);
				if (key === "promise") {
					this.trackProp("data");
					if (!this.options.experimental_prefetchInRender && this.#currentThenable.status === "pending") this.#currentThenable.reject(/* @__PURE__ */ new Error("experimental_prefetchInRender feature flag is not enabled"));
				}
				return Reflect.get(target, key);
			} });
		}
		trackProp(key) {
			this.#trackedProps.add(key);
		}
		getCurrentQuery() {
			return this.#currentQuery;
		}
		refetch({ ...options } = {}) {
			return this.fetch({ ...options });
		}
		fetchOptimistic(options) {
			const defaultedOptions = this.#client.defaultQueryOptions(options);
			const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
			return query.fetch().then(() => this.createResult(query, defaultedOptions));
		}
		fetch(fetchOptions) {
			return this.#executeFetch({
				...fetchOptions,
				cancelRefetch: fetchOptions.cancelRefetch ?? true
			}).then(() => {
				this.updateResult();
				return this.#currentResult;
			});
		}
		#executeFetch(fetchOptions) {
			this.#updateQuery();
			let promise = this.#currentQuery.fetch(this.options, fetchOptions);
			if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
			return promise;
		}
		#updateStaleTimeout() {
			this.#clearStaleTimeout();
			const staleTime = resolveStaleTime(this.options.staleTime, this.#currentQuery);
			if (isServer || this.#currentResult.isStale || !isValidTimeout(staleTime)) return;
			const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
			this.#staleTimeoutId = timeoutManager.setTimeout(() => {
				if (!this.#currentResult.isStale) this.updateResult();
			}, timeout);
		}
		#computeRefetchInterval() {
			return (typeof this.options.refetchInterval === "function" ? this.options.refetchInterval(this.#currentQuery) : this.options.refetchInterval) ?? false;
		}
		#updateRefetchInterval(nextInterval) {
			this.#clearRefetchInterval();
			this.#currentRefetchInterval = nextInterval;
			if (isServer || resolveEnabled(this.options.enabled, this.#currentQuery) === false || !isValidTimeout(this.#currentRefetchInterval) || this.#currentRefetchInterval === 0) return;
			this.#refetchIntervalId = timeoutManager.setInterval(() => {
				if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
			}, this.#currentRefetchInterval);
		}
		#updateTimers() {
			this.#updateStaleTimeout();
			this.#updateRefetchInterval(this.#computeRefetchInterval());
		}
		#clearStaleTimeout() {
			if (this.#staleTimeoutId) {
				timeoutManager.clearTimeout(this.#staleTimeoutId);
				this.#staleTimeoutId = void 0;
			}
		}
		#clearRefetchInterval() {
			if (this.#refetchIntervalId) {
				timeoutManager.clearInterval(this.#refetchIntervalId);
				this.#refetchIntervalId = void 0;
			}
		}
		createResult(query, options) {
			const prevQuery = this.#currentQuery;
			const prevOptions = this.options;
			const prevResult = this.#currentResult;
			const prevResultState = this.#currentResultState;
			const prevResultOptions = this.#currentResultOptions;
			const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
			const { state } = query;
			let newState = { ...state };
			let isPlaceholderData = false;
			let data;
			if (options._optimisticResults) {
				const mounted = this.hasListeners();
				const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
				const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
				if (fetchOnMount || fetchOptionally) newState = {
					...newState,
					...fetchState(state.data, query.options)
				};
				if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
			}
			let { error, errorUpdatedAt, status } = newState;
			data = newState.data;
			let skipSelect = false;
			if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
				let placeholderData;
				if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
					placeholderData = prevResult.data;
					skipSelect = true;
				} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
				if (placeholderData !== void 0) {
					status = "success";
					data = replaceData(prevResult?.data, placeholderData, options);
					isPlaceholderData = true;
				}
			}
			if (options.select && data !== void 0 && !skipSelect) if (prevResult && data === prevResultState?.data && options.select === this.#selectFn) data = this.#selectResult;
			else try {
				this.#selectFn = options.select;
				data = options.select(data);
				data = replaceData(prevResult?.data, data, options);
				this.#selectResult = data;
				this.#selectError = null;
			} catch (selectError) {
				this.#selectError = selectError;
			}
			if (this.#selectError) {
				error = this.#selectError;
				data = this.#selectResult;
				errorUpdatedAt = Date.now();
				status = "error";
			}
			const isFetching = newState.fetchStatus === "fetching";
			const isPending = status === "pending";
			const isError = status === "error";
			const isLoading = isPending && isFetching;
			const hasData = data !== void 0;
			const nextResult = {
				status,
				fetchStatus: newState.fetchStatus,
				isPending,
				isSuccess: status === "success",
				isError,
				isInitialLoading: isLoading,
				isLoading,
				data,
				dataUpdatedAt: newState.dataUpdatedAt,
				error,
				errorUpdatedAt,
				failureCount: newState.fetchFailureCount,
				failureReason: newState.fetchFailureReason,
				errorUpdateCount: newState.errorUpdateCount,
				isFetched: newState.dataUpdateCount > 0 || newState.errorUpdateCount > 0,
				isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
				isFetching,
				isRefetching: isFetching && !isPending,
				isLoadingError: isError && !hasData,
				isPaused: newState.fetchStatus === "paused",
				isPlaceholderData,
				isRefetchError: isError && hasData,
				isStale: isStale(query, options),
				refetch: this.refetch,
				promise: this.#currentThenable,
				isEnabled: resolveEnabled(options.enabled, query) !== false
			};
			if (this.options.experimental_prefetchInRender) {
				const finalizeThenableIfPossible = (thenable) => {
					if (nextResult.status === "error") thenable.reject(nextResult.error);
					else if (nextResult.data !== void 0) thenable.resolve(nextResult.data);
				};
				const recreateThenable = () => {
					const pending = this.#currentThenable = nextResult.promise = pendingThenable();
					finalizeThenableIfPossible(pending);
				};
				const prevThenable = this.#currentThenable;
				switch (prevThenable.status) {
					case "pending":
						if (query.queryHash === prevQuery.queryHash) finalizeThenableIfPossible(prevThenable);
						break;
					case "fulfilled":
						if (nextResult.status === "error" || nextResult.data !== prevThenable.value) recreateThenable();
						break;
					case "rejected":
						if (nextResult.status !== "error" || nextResult.error !== prevThenable.reason) recreateThenable();
						break;
				}
			}
			return nextResult;
		}
		updateResult() {
			const prevResult = this.#currentResult;
			const nextResult = this.createResult(this.#currentQuery, this.options);
			this.#currentResultState = this.#currentQuery.state;
			this.#currentResultOptions = this.options;
			if (this.#currentResultState.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
			if (shallowEqualObjects(nextResult, prevResult)) return;
			this.#currentResult = nextResult;
			const shouldNotifyListeners = () => {
				if (!prevResult) return true;
				const { notifyOnChangeProps } = this.options;
				const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
				if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
				const includedProps = new Set(notifyOnChangePropsValue ?? this.#trackedProps);
				if (this.options.throwOnError) includedProps.add("error");
				return Object.keys(this.#currentResult).some((key) => {
					const typedKey = key;
					return this.#currentResult[typedKey] !== prevResult[typedKey] && includedProps.has(typedKey);
				});
			};
			this.#notify({ listeners: shouldNotifyListeners() });
		}
		#updateQuery() {
			const query = this.#client.getQueryCache().build(this.#client, this.options);
			if (query === this.#currentQuery) return;
			const prevQuery = this.#currentQuery;
			this.#currentQuery = query;
			this.#currentQueryInitialState = query.state;
			if (this.hasListeners()) {
				prevQuery?.removeObserver(this);
				query.addObserver(this);
			}
		}
		onQueryUpdate() {
			this.updateResult();
			if (this.hasListeners()) this.#updateTimers();
		}
		#notify(notifyOptions) {
			notifyManager.batch(() => {
				if (notifyOptions.listeners) this.listeners.forEach((listener) => {
					listener(this.#currentResult);
				});
				this.#client.getQueryCache().notify({
					query: this.#currentQuery,
					type: "observerResultsUpdated"
				});
			});
		}
	};
	function shouldLoadOnMount(query, options) {
		return resolveEnabled(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && options.retryOnMount === false);
	}
	function shouldFetchOnMount(query, options) {
		return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
	}
	function shouldFetchOn(query, options, field) {
		if (resolveEnabled(options.enabled, query) !== false && resolveStaleTime(options.staleTime, query) !== "static") {
			const value = typeof field === "function" ? field(query) : field;
			return value === "always" || value !== false && isStale(query, options);
		}
		return false;
	}
	function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
		return (query !== prevQuery || resolveEnabled(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
	}
	function isStale(query, options) {
		return resolveEnabled(options.enabled, query) !== false && query.isStaleByTime(resolveStaleTime(options.staleTime, query));
	}
	function shouldAssignObserverCurrentProperties(observer, optimisticResult) {
		if (!shallowEqualObjects(observer.getCurrentResult(), optimisticResult)) return true;
		return false;
	}

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
	function infiniteQueryBehavior(pages) {
		return { onFetch: (context, query) => {
			const options = context.options;
			const direction = context.fetchOptions?.meta?.fetchMore?.direction;
			const oldPages = context.state.data?.pages || [];
			const oldPageParams = context.state.data?.pageParams || [];
			let result = {
				pages: [],
				pageParams: []
			};
			let currentPage = 0;
			const fetchFn = async () => {
				let cancelled = false;
				const addSignalProperty = (object) => {
					addConsumeAwareSignal(object, () => context.signal, () => cancelled = true);
				};
				const queryFn = ensureQueryFn(context.options, context.fetchOptions);
				const fetchPage = async (data, param, previous) => {
					if (cancelled) return Promise.reject();
					if (param == null && data.pages.length) return Promise.resolve(data);
					const createQueryFnContext = () => {
						const queryFnContext2 = {
							client: context.client,
							queryKey: context.queryKey,
							pageParam: param,
							direction: previous ? "backward" : "forward",
							meta: context.options.meta
						};
						addSignalProperty(queryFnContext2);
						return queryFnContext2;
					};
					const queryFnContext = createQueryFnContext();
					const page = await queryFn(queryFnContext);
					const { maxPages } = context.options;
					const addTo = previous ? addToStart : addToEnd;
					return {
						pages: addTo(data.pages, page, maxPages),
						pageParams: addTo(data.pageParams, param, maxPages)
					};
				};
				if (direction && oldPages.length) {
					const previous = direction === "backward";
					const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
					const oldData = {
						pages: oldPages,
						pageParams: oldPageParams
					};
					result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
				} else {
					const remainingPages = pages ?? oldPages.length;
					do {
						const param = currentPage === 0 ? oldPageParams[0] ?? options.initialPageParam : getNextPageParam(options, result);
						if (currentPage > 0 && param == null) break;
						result = await fetchPage(result, param);
						currentPage++;
					} while (currentPage < remainingPages);
				}
				return result;
			};
			if (context.options.persister) context.fetchFn = () => {
				return context.options.persister?.(fetchFn, {
					client: context.client,
					queryKey: context.queryKey,
					meta: context.options.meta,
					signal: context.signal
				}, query);
			};
			else context.fetchFn = fetchFn;
		} };
	}
	function getNextPageParam(options, { pages, pageParams }) {
		const lastIndex = pages.length - 1;
		return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
	}
	function getPreviousPageParam(options, { pages, pageParams }) {
		return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
	}
	function hasNextPage(options, data) {
		if (!data) return false;
		return getNextPageParam(options, data) != null;
	}
	function hasPreviousPage(options, data) {
		if (!data || !options.getPreviousPageParam) return false;
		return getPreviousPageParam(options, data) != null;
	}

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js
	var InfiniteQueryObserver = class extends QueryObserver {
		constructor(client, options) {
			super(client, options);
		}
		bindMethods() {
			super.bindMethods();
			this.fetchNextPage = this.fetchNextPage.bind(this);
			this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
		}
		setOptions(options) {
			super.setOptions({
				...options,
				behavior: infiniteQueryBehavior()
			});
		}
		getOptimisticResult(options) {
			options.behavior = infiniteQueryBehavior();
			return super.getOptimisticResult(options);
		}
		fetchNextPage(options) {
			return this.fetch({
				...options,
				meta: { fetchMore: { direction: "forward" } }
			});
		}
		fetchPreviousPage(options) {
			return this.fetch({
				...options,
				meta: { fetchMore: { direction: "backward" } }
			});
		}
		createResult(query, options) {
			const { state } = query;
			const parentResult = super.createResult(query, options);
			const { isFetching, isRefetching, isError, isRefetchError } = parentResult;
			const fetchDirection = state.fetchMeta?.fetchMore?.direction;
			const isFetchNextPageError = isError && fetchDirection === "forward";
			const isFetchingNextPage = isFetching && fetchDirection === "forward";
			const isFetchPreviousPageError = isError && fetchDirection === "backward";
			const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
			return {
				...parentResult,
				fetchNextPage: this.fetchNextPage,
				fetchPreviousPage: this.fetchPreviousPage,
				hasNextPage: hasNextPage(options, state.data),
				hasPreviousPage: hasPreviousPage(options, state.data),
				isFetchNextPageError,
				isFetchingNextPage,
				isFetchPreviousPageError,
				isFetchingPreviousPage,
				isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
				isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
			};
		}
	};

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutation.js
	var Mutation = class extends Removable {
		#client;
		#observers;
		#mutationCache;
		#retryer;
		constructor(config) {
			super();
			this.#client = config.client;
			this.mutationId = config.mutationId;
			this.#mutationCache = config.mutationCache;
			this.#observers = [];
			this.state = config.state || getDefaultState();
			this.setOptions(config.options);
			this.scheduleGc();
		}
		setOptions(options) {
			this.options = options;
			this.updateGcTime(this.options.gcTime);
		}
		get meta() {
			return this.options.meta;
		}
		addObserver(observer) {
			if (!this.#observers.includes(observer)) {
				this.#observers.push(observer);
				this.clearGcTimeout();
				this.#mutationCache.notify({
					type: "observerAdded",
					mutation: this,
					observer
				});
			}
		}
		removeObserver(observer) {
			this.#observers = this.#observers.filter((x) => x !== observer);
			this.scheduleGc();
			this.#mutationCache.notify({
				type: "observerRemoved",
				mutation: this,
				observer
			});
		}
		optionalRemove() {
			if (!this.#observers.length) if (this.state.status === "pending") this.scheduleGc();
			else this.#mutationCache.remove(this);
		}
		continue() {
			return this.#retryer?.continue() ?? this.execute(this.state.variables);
		}
		async execute(variables) {
			const onContinue = () => {
				this.#dispatch({ type: "continue" });
			};
			const mutationFnContext = {
				client: this.#client,
				meta: this.options.meta,
				mutationKey: this.options.mutationKey
			};
			this.#retryer = createRetryer({
				fn: () => {
					if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
					return this.options.mutationFn(variables, mutationFnContext);
				},
				onFail: (failureCount, error) => {
					this.#dispatch({
						type: "failed",
						failureCount,
						error
					});
				},
				onPause: () => {
					this.#dispatch({ type: "pause" });
				},
				onContinue,
				retry: this.options.retry ?? 0,
				retryDelay: this.options.retryDelay,
				networkMode: this.options.networkMode,
				canRun: () => this.#mutationCache.canRun(this)
			});
			const restored = this.state.status === "pending";
			const isPaused = !this.#retryer.canStart();
			try {
				if (restored) onContinue();
				else {
					this.#dispatch({
						type: "pending",
						variables,
						isPaused
					});
					await this.#mutationCache.config.onMutate?.(variables, this, mutationFnContext);
					const context = await this.options.onMutate?.(variables, mutationFnContext);
					if (context !== this.state.context) this.#dispatch({
						type: "pending",
						context,
						variables,
						isPaused
					});
				}
				const data = await this.#retryer.start();
				await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
				await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
				await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
				await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
				this.#dispatch({
					type: "success",
					data
				});
				return data;
			} catch (error) {
				try {
					await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
					await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
					await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
					await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
					throw error;
				} finally {
					this.#dispatch({
						type: "error",
						error
					});
				}
			} finally {
				this.#mutationCache.runNext(this);
			}
		}
		#dispatch(action) {
			const reducer = (state) => {
				switch (action.type) {
					case "failed": return {
						...state,
						failureCount: action.failureCount,
						failureReason: action.error
					};
					case "pause": return {
						...state,
						isPaused: true
					};
					case "continue": return {
						...state,
						isPaused: false
					};
					case "pending": return {
						...state,
						context: action.context,
						data: void 0,
						failureCount: 0,
						failureReason: null,
						error: null,
						isPaused: action.isPaused,
						status: "pending",
						variables: action.variables,
						submittedAt: Date.now()
					};
					case "success": return {
						...state,
						data: action.data,
						failureCount: 0,
						failureReason: null,
						error: null,
						status: "success",
						isPaused: false
					};
					case "error": return {
						...state,
						data: void 0,
						error: action.error,
						failureCount: state.failureCount + 1,
						failureReason: action.error,
						isPaused: false,
						status: "error"
					};
				}
			};
			this.state = reducer(this.state);
			notifyManager.batch(() => {
				this.#observers.forEach((observer) => {
					observer.onMutationUpdate(action);
				});
				this.#mutationCache.notify({
					mutation: this,
					type: "updated",
					action
				});
			});
		}
	};
	function getDefaultState() {
		return {
			context: void 0,
			data: void 0,
			error: null,
			failureCount: 0,
			failureReason: null,
			isPaused: false,
			status: "idle",
			variables: void 0,
			submittedAt: 0
		};
	}

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationCache.js
	var MutationCache = class extends Subscribable {
		constructor(config = {}) {
			super();
			this.config = config;
			this.#mutations = /* @__PURE__ */ new Set();
			this.#scopes = /* @__PURE__ */ new Map();
			this.#mutationId = 0;
		}
		#mutations;
		#scopes;
		#mutationId;
		build(client, options, state) {
			const mutation = new Mutation({
				client,
				mutationCache: this,
				mutationId: ++this.#mutationId,
				options: client.defaultMutationOptions(options),
				state
			});
			this.add(mutation);
			return mutation;
		}
		add(mutation) {
			this.#mutations.add(mutation);
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = this.#scopes.get(scope);
				if (scopedMutations) scopedMutations.push(mutation);
				else this.#scopes.set(scope, [mutation]);
			}
			this.notify({
				type: "added",
				mutation
			});
		}
		remove(mutation) {
			if (this.#mutations.delete(mutation)) {
				const scope = scopeFor(mutation);
				if (typeof scope === "string") {
					const scopedMutations = this.#scopes.get(scope);
					if (scopedMutations) {
						if (scopedMutations.length > 1) {
							const index = scopedMutations.indexOf(mutation);
							if (index !== -1) scopedMutations.splice(index, 1);
						} else if (scopedMutations[0] === mutation) this.#scopes.delete(scope);
					}
				}
			}
			this.notify({
				type: "removed",
				mutation
			});
		}
		canRun(mutation) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const firstPendingMutation = this.#scopes.get(scope)?.find((m) => m.state.status === "pending");
				return !firstPendingMutation || firstPendingMutation === mutation;
			} else return true;
		}
		runNext(mutation) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") return (this.#scopes.get(scope)?.find((m) => m !== mutation && m.state.isPaused))?.continue() ?? Promise.resolve();
			else return Promise.resolve();
		}
		clear() {
			notifyManager.batch(() => {
				this.#mutations.forEach((mutation) => {
					this.notify({
						type: "removed",
						mutation
					});
				});
				this.#mutations.clear();
				this.#scopes.clear();
			});
		}
		getAll() {
			return Array.from(this.#mutations);
		}
		find(filters) {
			const defaultedFilters = {
				exact: true,
				...filters
			};
			return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
		}
		findAll(filters = {}) {
			return this.getAll().filter((mutation) => matchMutation(filters, mutation));
		}
		notify(event) {
			notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(event);
				});
			});
		}
		resumePausedMutations() {
			const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
			return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop))));
		}
	};
	function scopeFor(mutation) {
		return mutation.options.scope?.id;
	}

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationObserver.js
	var MutationObserver = class extends Subscribable {
		#client;
		#currentResult = void 0;
		#currentMutation;
		#mutateOptions;
		constructor(client, options) {
			super();
			this.#client = client;
			this.setOptions(options);
			this.bindMethods();
			this.#updateResult();
		}
		bindMethods() {
			this.mutate = this.mutate.bind(this);
			this.reset = this.reset.bind(this);
		}
		setOptions(options) {
			const prevOptions = this.options;
			this.options = this.#client.defaultMutationOptions(options);
			if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
				type: "observerOptionsUpdated",
				mutation: this.#currentMutation,
				observer: this
			});
			if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
			else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
		}
		onUnsubscribe() {
			if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
		}
		onMutationUpdate(action) {
			this.#updateResult();
			this.#notify(action);
		}
		getCurrentResult() {
			return this.#currentResult;
		}
		reset() {
			this.#currentMutation?.removeObserver(this);
			this.#currentMutation = void 0;
			this.#updateResult();
			this.#notify();
		}
		mutate(variables, options) {
			this.#mutateOptions = options;
			this.#currentMutation?.removeObserver(this);
			this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
			this.#currentMutation.addObserver(this);
			return this.#currentMutation.execute(variables);
		}
		#updateResult() {
			const state = this.#currentMutation?.state ?? getDefaultState();
			this.#currentResult = {
				...state,
				isPending: state.status === "pending",
				isSuccess: state.status === "success",
				isError: state.status === "error",
				isIdle: state.status === "idle",
				mutate: this.mutate,
				reset: this.reset
			};
		}
		#notify(action) {
			notifyManager.batch(() => {
				if (this.#mutateOptions && this.hasListeners()) {
					const variables = this.#currentResult.variables;
					const onMutateResult = this.#currentResult.context;
					const context = {
						client: this.#client,
						meta: this.options.meta,
						mutationKey: this.options.mutationKey
					};
					if (action?.type === "success") {
						this.#mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
						this.#mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} else if (action?.type === "error") {
						this.#mutateOptions.onError?.(action.error, variables, onMutateResult, context);
						this.#mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					}
				}
				this.listeners.forEach((listener) => {
					listener(this.#currentResult);
				});
			});
		}
	};

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryCache.js
	var QueryCache = class extends Subscribable {
		constructor(config = {}) {
			super();
			this.config = config;
			this.#queries = /* @__PURE__ */ new Map();
		}
		#queries;
		build(client, options, state) {
			const queryKey = options.queryKey;
			const queryHash = options.queryHash ?? hashQueryKeyByOptions(queryKey, options);
			let query = this.get(queryHash);
			if (!query) {
				query = new Query({
					client,
					queryKey,
					queryHash,
					options: client.defaultQueryOptions(options),
					state,
					defaultOptions: client.getQueryDefaults(queryKey)
				});
				this.add(query);
			}
			return query;
		}
		add(query) {
			if (!this.#queries.has(query.queryHash)) {
				this.#queries.set(query.queryHash, query);
				this.notify({
					type: "added",
					query
				});
			}
		}
		remove(query) {
			const queryInMap = this.#queries.get(query.queryHash);
			if (queryInMap) {
				query.destroy();
				if (queryInMap === query) this.#queries.delete(query.queryHash);
				this.notify({
					type: "removed",
					query
				});
			}
		}
		clear() {
			notifyManager.batch(() => {
				this.getAll().forEach((query) => {
					this.remove(query);
				});
			});
		}
		get(queryHash) {
			return this.#queries.get(queryHash);
		}
		getAll() {
			return [...this.#queries.values()];
		}
		find(filters) {
			const defaultedFilters = {
				exact: true,
				...filters
			};
			return this.getAll().find((query) => matchQuery(defaultedFilters, query));
		}
		findAll(filters = {}) {
			const queries = this.getAll();
			return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
		}
		notify(event) {
			notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(event);
				});
			});
		}
		onFocus() {
			notifyManager.batch(() => {
				this.getAll().forEach((query) => {
					query.onFocus();
				});
			});
		}
		onOnline() {
			notifyManager.batch(() => {
				this.getAll().forEach((query) => {
					query.onOnline();
				});
			});
		}
	};

//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryClient.js
	var QueryClient = class {
		#queryCache;
		#mutationCache;
		#defaultOptions;
		#queryDefaults;
		#mutationDefaults;
		#mountCount;
		#unsubscribeFocus;
		#unsubscribeOnline;
		constructor(config = {}) {
			this.#queryCache = config.queryCache || new QueryCache();
			this.#mutationCache = config.mutationCache || new MutationCache();
			this.#defaultOptions = config.defaultOptions || {};
			this.#queryDefaults = /* @__PURE__ */ new Map();
			this.#mutationDefaults = /* @__PURE__ */ new Map();
			this.#mountCount = 0;
		}
		mount() {
			this.#mountCount++;
			if (this.#mountCount !== 1) return;
			this.#unsubscribeFocus = focusManager.subscribe(async (focused) => {
				if (focused) {
					await this.resumePausedMutations();
					this.#queryCache.onFocus();
				}
			});
			this.#unsubscribeOnline = onlineManager.subscribe(async (online) => {
				if (online) {
					await this.resumePausedMutations();
					this.#queryCache.onOnline();
				}
			});
		}
		unmount() {
			this.#mountCount--;
			if (this.#mountCount !== 0) return;
			this.#unsubscribeFocus?.();
			this.#unsubscribeFocus = void 0;
			this.#unsubscribeOnline?.();
			this.#unsubscribeOnline = void 0;
		}
		isFetching(filters) {
			return this.#queryCache.findAll({
				...filters,
				fetchStatus: "fetching"
			}).length;
		}
		isMutating(filters) {
			return this.#mutationCache.findAll({
				...filters,
				status: "pending"
			}).length;
		}
		/**
		* Imperative (non-reactive) way to retrieve data for a QueryKey.
		* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
		*
		* Hint: Do not use this function inside a component, because it won't receive updates.
		* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
		*/
		getQueryData(queryKey) {
			const options = this.defaultQueryOptions({ queryKey });
			return this.#queryCache.get(options.queryHash)?.state.data;
		}
		ensureQueryData(options) {
			const defaultedOptions = this.defaultQueryOptions(options);
			const query = this.#queryCache.build(this, defaultedOptions);
			const cachedData = query.state.data;
			if (cachedData === void 0) return this.fetchQuery(options);
			if (options.revalidateIfStale && query.isStaleByTime(resolveStaleTime(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
			return Promise.resolve(cachedData);
		}
		getQueriesData(filters) {
			return this.#queryCache.findAll(filters).map(({ queryKey, state }) => {
				return [queryKey, state.data];
			});
		}
		setQueryData(queryKey, updater, options) {
			const defaultedOptions = this.defaultQueryOptions({ queryKey });
			const prevData = this.#queryCache.get(defaultedOptions.queryHash)?.state.data;
			const data = functionalUpdate(updater, prevData);
			if (data === void 0) return;
			return this.#queryCache.build(this, defaultedOptions).setData(data, {
				...options,
				manual: true
			});
		}
		setQueriesData(filters, updater, options) {
			return notifyManager.batch(() => this.#queryCache.findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
		}
		getQueryState(queryKey) {
			const options = this.defaultQueryOptions({ queryKey });
			return this.#queryCache.get(options.queryHash)?.state;
		}
		removeQueries(filters) {
			const queryCache = this.#queryCache;
			notifyManager.batch(() => {
				queryCache.findAll(filters).forEach((query) => {
					queryCache.remove(query);
				});
			});
		}
		resetQueries(filters, options) {
			const queryCache = this.#queryCache;
			return notifyManager.batch(() => {
				queryCache.findAll(filters).forEach((query) => {
					query.reset();
				});
				return this.refetchQueries({
					type: "active",
					...filters
				}, options);
			});
		}
		cancelQueries(filters, cancelOptions = {}) {
			const defaultedCancelOptions = {
				revert: true,
				...cancelOptions
			};
			const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
			return Promise.all(promises).then(noop).catch(noop);
		}
		invalidateQueries(filters, options = {}) {
			return notifyManager.batch(() => {
				this.#queryCache.findAll(filters).forEach((query) => {
					query.invalidate();
				});
				if (filters?.refetchType === "none") return Promise.resolve();
				return this.refetchQueries({
					...filters,
					type: filters?.refetchType ?? filters?.type ?? "active"
				}, options);
			});
		}
		refetchQueries(filters, options = {}) {
			const fetchOptions = {
				...options,
				cancelRefetch: options.cancelRefetch ?? true
			};
			const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
				let promise = query.fetch(void 0, fetchOptions);
				if (!fetchOptions.throwOnError) promise = promise.catch(noop);
				return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
			}));
			return Promise.all(promises).then(noop);
		}
		fetchQuery(options) {
			const defaultedOptions = this.defaultQueryOptions(options);
			if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
			const query = this.#queryCache.build(this, defaultedOptions);
			return query.isStaleByTime(resolveStaleTime(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
		}
		prefetchQuery(options) {
			return this.fetchQuery(options).then(noop).catch(noop);
		}
		fetchInfiniteQuery(options) {
			options.behavior = infiniteQueryBehavior(options.pages);
			return this.fetchQuery(options);
		}
		prefetchInfiniteQuery(options) {
			return this.fetchInfiniteQuery(options).then(noop).catch(noop);
		}
		ensureInfiniteQueryData(options) {
			options.behavior = infiniteQueryBehavior(options.pages);
			return this.ensureQueryData(options);
		}
		resumePausedMutations() {
			if (onlineManager.isOnline()) return this.#mutationCache.resumePausedMutations();
			return Promise.resolve();
		}
		getQueryCache() {
			return this.#queryCache;
		}
		getMutationCache() {
			return this.#mutationCache;
		}
		getDefaultOptions() {
			return this.#defaultOptions;
		}
		setDefaultOptions(options) {
			this.#defaultOptions = options;
		}
		setQueryDefaults(queryKey, options) {
			this.#queryDefaults.set(hashKey(queryKey), {
				queryKey,
				defaultOptions: options
			});
		}
		getQueryDefaults(queryKey) {
			const defaults = [...this.#queryDefaults.values()];
			const result = {};
			defaults.forEach((queryDefault) => {
				if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
			});
			return result;
		}
		setMutationDefaults(mutationKey, options) {
			this.#mutationDefaults.set(hashKey(mutationKey), {
				mutationKey,
				defaultOptions: options
			});
		}
		getMutationDefaults(mutationKey) {
			const defaults = [...this.#mutationDefaults.values()];
			const result = {};
			defaults.forEach((queryDefault) => {
				if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
			});
			return result;
		}
		defaultQueryOptions(options) {
			if (options._defaulted) return options;
			const defaultedOptions = {
				...this.#defaultOptions.queries,
				...this.getQueryDefaults(options.queryKey),
				...options,
				_defaulted: true
			};
			if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
			if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
			if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
			if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
			if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
			return defaultedOptions;
		}
		defaultMutationOptions(options) {
			if (options?._defaulted) return options;
			return {
				...this.#defaultOptions.mutations,
				...options?.mutationKey && this.getMutationDefaults(options.mutationKey),
				...options,
				_defaulted: true
			};
		}
		clear() {
			this.#queryCache.clear();
			this.#mutationCache.clear();
		}
	};

//#endregion
//#region node_modules/react/cjs/react-jsx-runtime.development.js
/**
	* @license React
	* react-jsx-runtime.development.js
	*
	* Copyright (c) Facebook, Inc. and its affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_react_jsx_runtime_development = /* @__PURE__ */ __commonJSMin(((exports) => {
		(function() {
			"use strict";
			var React = (globalThis.React);
			var REACT_ELEMENT_TYPE = Symbol.for("react.element");
			var REACT_PORTAL_TYPE = Symbol.for("react.portal");
			var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
			var REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
			var REACT_PROFILER_TYPE = Symbol.for("react.profiler");
			var REACT_PROVIDER_TYPE = Symbol.for("react.provider");
			var REACT_CONTEXT_TYPE = Symbol.for("react.context");
			var REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
			var REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
			var REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list");
			var REACT_MEMO_TYPE = Symbol.for("react.memo");
			var REACT_LAZY_TYPE = Symbol.for("react.lazy");
			var REACT_OFFSCREEN_TYPE = Symbol.for("react.offscreen");
			var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
			var FAUX_ITERATOR_SYMBOL = "@@iterator";
			function getIteratorFn(maybeIterable) {
				if (maybeIterable === null || typeof maybeIterable !== "object") return null;
				var maybeIterator = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL];
				if (typeof maybeIterator === "function") return maybeIterator;
				return null;
			}
			var ReactSharedInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
			function error(format) {
				for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) args[_key2 - 1] = arguments[_key2];
				printWarning("error", format, args);
			}
			function printWarning(level, format, args) {
				var stack = ReactSharedInternals.ReactDebugCurrentFrame.getStackAddendum();
				if (stack !== "") {
					format += "%s";
					args = args.concat([stack]);
				}
				var argsWithFormat = args.map(function(item) {
					return String(item);
				});
				argsWithFormat.unshift("Warning: " + format);
				Function.prototype.apply.call(console[level], console, argsWithFormat);
			}
			var enableScopeAPI = false;
			var enableCacheElement = false;
			var enableTransitionTracing = false;
			var enableLegacyHidden = false;
			var enableDebugTracing = false;
			var REACT_MODULE_REFERENCE = Symbol.for("react.module.reference");
			function isValidElementType(type) {
				if (typeof type === "string" || typeof type === "function") return true;
				if (type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || enableDebugTracing || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || enableLegacyHidden || type === REACT_OFFSCREEN_TYPE || enableScopeAPI || enableCacheElement || enableTransitionTracing) return true;
				if (typeof type === "object" && type !== null) {
					if (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_MODULE_REFERENCE || type.getModuleId !== void 0) return true;
				}
				return false;
			}
			function getWrappedName(outerType, innerType, wrapperName) {
				var displayName = outerType.displayName;
				if (displayName) return displayName;
				var functionName = innerType.displayName || innerType.name || "";
				return functionName !== "" ? wrapperName + "(" + functionName + ")" : wrapperName;
			}
			function getContextName(type) {
				return type.displayName || "Context";
			}
			function getComponentNameFromType(type) {
				if (type == null) return null;
				if (typeof type.tag === "number") error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue.");
				if (typeof type === "function") return type.displayName || type.name || null;
				if (typeof type === "string") return type;
				switch (type) {
					case REACT_FRAGMENT_TYPE: return "Fragment";
					case REACT_PORTAL_TYPE: return "Portal";
					case REACT_PROFILER_TYPE: return "Profiler";
					case REACT_STRICT_MODE_TYPE: return "StrictMode";
					case REACT_SUSPENSE_TYPE: return "Suspense";
					case REACT_SUSPENSE_LIST_TYPE: return "SuspenseList";
				}
				if (typeof type === "object") switch (type.$$typeof) {
					case REACT_CONTEXT_TYPE: return getContextName(type) + ".Consumer";
					case REACT_PROVIDER_TYPE: return getContextName(type._context) + ".Provider";
					case REACT_FORWARD_REF_TYPE: return getWrappedName(type, type.render, "ForwardRef");
					case REACT_MEMO_TYPE:
						var outerName = type.displayName || null;
						if (outerName !== null) return outerName;
						return getComponentNameFromType(type.type) || "Memo";
					case REACT_LAZY_TYPE:
						var lazyComponent = type;
						var payload = lazyComponent._payload;
						var init = lazyComponent._init;
						try {
							return getComponentNameFromType(init(payload));
						} catch (x) {
							return null;
						}
				}
				return null;
			}
			var assign = Object.assign;
			var disabledDepth = 0;
			var prevLog;
			var prevInfo;
			var prevWarn;
			var prevError;
			var prevGroup;
			var prevGroupCollapsed;
			var prevGroupEnd;
			function disabledLog() {}
			disabledLog.__reactDisabledLog = true;
			function disableLogs() {
				if (disabledDepth === 0) {
					prevLog = console.log;
					prevInfo = console.info;
					prevWarn = console.warn;
					prevError = console.error;
					prevGroup = console.group;
					prevGroupCollapsed = console.groupCollapsed;
					prevGroupEnd = console.groupEnd;
					var props = {
						configurable: true,
						enumerable: true,
						value: disabledLog,
						writable: true
					};
					Object.defineProperties(console, {
						info: props,
						log: props,
						warn: props,
						error: props,
						group: props,
						groupCollapsed: props,
						groupEnd: props
					});
				}
				disabledDepth++;
			}
			function reenableLogs() {
				disabledDepth--;
				if (disabledDepth === 0) {
					var props = {
						configurable: true,
						enumerable: true,
						writable: true
					};
					Object.defineProperties(console, {
						log: assign({}, props, { value: prevLog }),
						info: assign({}, props, { value: prevInfo }),
						warn: assign({}, props, { value: prevWarn }),
						error: assign({}, props, { value: prevError }),
						group: assign({}, props, { value: prevGroup }),
						groupCollapsed: assign({}, props, { value: prevGroupCollapsed }),
						groupEnd: assign({}, props, { value: prevGroupEnd })
					});
				}
				if (disabledDepth < 0) error("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
			}
			var ReactCurrentDispatcher = ReactSharedInternals.ReactCurrentDispatcher;
			var prefix;
			function describeBuiltInComponentFrame(name, source, ownerFn) {
				if (prefix === void 0) try {
					throw Error();
				} catch (x) {
					var match = x.stack.trim().match(/\n( *(at )?)/);
					prefix = match && match[1] || "";
				}
				return "\n" + prefix + name;
			}
			var reentry = false;
			var componentFrameCache = new (typeof WeakMap === "function" ? WeakMap : Map)();
			function describeNativeComponentFrame(fn, construct) {
				if (!fn || reentry) return "";
				var frame = componentFrameCache.get(fn);
				if (frame !== void 0) return frame;
				var control;
				reentry = true;
				var previousPrepareStackTrace = Error.prepareStackTrace;
				Error.prepareStackTrace = void 0;
				var previousDispatcher = ReactCurrentDispatcher.current;
				ReactCurrentDispatcher.current = null;
				disableLogs();
				try {
					if (construct) {
						var Fake = function() {
							throw Error();
						};
						Object.defineProperty(Fake.prototype, "props", { set: function() {
							throw Error();
						} });
						if (typeof Reflect === "object" && Reflect.construct) {
							try {
								Reflect.construct(Fake, []);
							} catch (x) {
								control = x;
							}
							Reflect.construct(fn, [], Fake);
						} else {
							try {
								Fake.call();
							} catch (x) {
								control = x;
							}
							fn.call(Fake.prototype);
						}
					} else {
						try {
							throw Error();
						} catch (x) {
							control = x;
						}
						fn();
					}
				} catch (sample) {
					if (sample && control && typeof sample.stack === "string") {
						var sampleLines = sample.stack.split("\n");
						var controlLines = control.stack.split("\n");
						var s = sampleLines.length - 1;
						var c = controlLines.length - 1;
						while (s >= 1 && c >= 0 && sampleLines[s] !== controlLines[c]) c--;
						for (; s >= 1 && c >= 0; s--, c--) if (sampleLines[s] !== controlLines[c]) {
							if (s !== 1 || c !== 1) do {
								s--;
								c--;
								if (c < 0 || sampleLines[s] !== controlLines[c]) {
									var _frame = "\n" + sampleLines[s].replace(" at new ", " at ");
									if (fn.displayName && _frame.includes("<anonymous>")) _frame = _frame.replace("<anonymous>", fn.displayName);
									if (typeof fn === "function") componentFrameCache.set(fn, _frame);
									return _frame;
								}
							} while (s >= 1 && c >= 0);
							break;
						}
					}
				} finally {
					reentry = false;
					ReactCurrentDispatcher.current = previousDispatcher;
					reenableLogs();
					Error.prepareStackTrace = previousPrepareStackTrace;
				}
				var name = fn ? fn.displayName || fn.name : "";
				var syntheticFrame = name ? describeBuiltInComponentFrame(name) : "";
				if (typeof fn === "function") componentFrameCache.set(fn, syntheticFrame);
				return syntheticFrame;
			}
			function describeFunctionComponentFrame(fn, source, ownerFn) {
				return describeNativeComponentFrame(fn, false);
			}
			function shouldConstruct(Component) {
				var prototype = Component.prototype;
				return !!(prototype && prototype.isReactComponent);
			}
			function describeUnknownElementTypeFrameInDEV(type, source, ownerFn) {
				if (type == null) return "";
				if (typeof type === "function") return describeNativeComponentFrame(type, shouldConstruct(type));
				if (typeof type === "string") return describeBuiltInComponentFrame(type);
				switch (type) {
					case REACT_SUSPENSE_TYPE: return describeBuiltInComponentFrame("Suspense");
					case REACT_SUSPENSE_LIST_TYPE: return describeBuiltInComponentFrame("SuspenseList");
				}
				if (typeof type === "object") switch (type.$$typeof) {
					case REACT_FORWARD_REF_TYPE: return describeFunctionComponentFrame(type.render);
					case REACT_MEMO_TYPE: return describeUnknownElementTypeFrameInDEV(type.type, source, ownerFn);
					case REACT_LAZY_TYPE:
						var lazyComponent = type;
						var payload = lazyComponent._payload;
						var init = lazyComponent._init;
						try {
							return describeUnknownElementTypeFrameInDEV(init(payload), source, ownerFn);
						} catch (x) {}
				}
				return "";
			}
			var hasOwnProperty = Object.prototype.hasOwnProperty;
			var loggedTypeFailures = {};
			var ReactDebugCurrentFrame = ReactSharedInternals.ReactDebugCurrentFrame;
			function setCurrentlyValidatingElement(element) {
				if (element) {
					var owner = element._owner;
					var stack = describeUnknownElementTypeFrameInDEV(element.type, element._source, owner ? owner.type : null);
					ReactDebugCurrentFrame.setExtraStackFrame(stack);
				} else ReactDebugCurrentFrame.setExtraStackFrame(null);
			}
			function checkPropTypes(typeSpecs, values, location, componentName, element) {
				var has = Function.call.bind(hasOwnProperty);
				for (var typeSpecName in typeSpecs) if (has(typeSpecs, typeSpecName)) {
					var error$1 = void 0;
					try {
						if (typeof typeSpecs[typeSpecName] !== "function") {
							var err = Error((componentName || "React class") + ": " + location + " type `" + typeSpecName + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof typeSpecs[typeSpecName] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
							err.name = "Invariant Violation";
							throw err;
						}
						error$1 = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
					} catch (ex) {
						error$1 = ex;
					}
					if (error$1 && !(error$1 instanceof Error)) {
						setCurrentlyValidatingElement(element);
						error("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", componentName || "React class", location, typeSpecName, typeof error$1);
						setCurrentlyValidatingElement(null);
					}
					if (error$1 instanceof Error && !(error$1.message in loggedTypeFailures)) {
						loggedTypeFailures[error$1.message] = true;
						setCurrentlyValidatingElement(element);
						error("Failed %s type: %s", location, error$1.message);
						setCurrentlyValidatingElement(null);
					}
				}
			}
			var isArrayImpl = Array.isArray;
			function isArray(a) {
				return isArrayImpl(a);
			}
			function typeName(value) {
				return typeof Symbol === "function" && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
			}
			function willCoercionThrow(value) {
				try {
					testStringCoercion(value);
					return false;
				} catch (e) {
					return true;
				}
			}
			function testStringCoercion(value) {
				return "" + value;
			}
			function checkKeyStringCoercion(value) {
				if (willCoercionThrow(value)) {
					error("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", typeName(value));
					return testStringCoercion(value);
				}
			}
			var ReactCurrentOwner = ReactSharedInternals.ReactCurrentOwner;
			var RESERVED_PROPS = {
				key: true,
				ref: true,
				__self: true,
				__source: true
			};
			var specialPropKeyWarningShown;
			var specialPropRefWarningShown;
			var didWarnAboutStringRefs = {};
			function hasValidRef(config) {
				if (hasOwnProperty.call(config, "ref")) {
					var getter = Object.getOwnPropertyDescriptor(config, "ref").get;
					if (getter && getter.isReactWarning) return false;
				}
				return config.ref !== void 0;
			}
			function hasValidKey(config) {
				if (hasOwnProperty.call(config, "key")) {
					var getter = Object.getOwnPropertyDescriptor(config, "key").get;
					if (getter && getter.isReactWarning) return false;
				}
				return config.key !== void 0;
			}
			function warnIfStringRefCannotBeAutoConverted(config, self) {
				if (typeof config.ref === "string" && ReactCurrentOwner.current && self && ReactCurrentOwner.current.stateNode !== self) {
					var componentName = getComponentNameFromType(ReactCurrentOwner.current.type);
					if (!didWarnAboutStringRefs[componentName]) {
						error("Component \"%s\" contains the string ref \"%s\". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref", getComponentNameFromType(ReactCurrentOwner.current.type), config.ref);
						didWarnAboutStringRefs[componentName] = true;
					}
				}
			}
			function defineKeyPropWarningGetter(props, displayName) {
				var warnAboutAccessingKey = function() {
					if (!specialPropKeyWarningShown) {
						specialPropKeyWarningShown = true;
						error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", displayName);
					}
				};
				warnAboutAccessingKey.isReactWarning = true;
				Object.defineProperty(props, "key", {
					get: warnAboutAccessingKey,
					configurable: true
				});
			}
			function defineRefPropWarningGetter(props, displayName) {
				var warnAboutAccessingRef = function() {
					if (!specialPropRefWarningShown) {
						specialPropRefWarningShown = true;
						error("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", displayName);
					}
				};
				warnAboutAccessingRef.isReactWarning = true;
				Object.defineProperty(props, "ref", {
					get: warnAboutAccessingRef,
					configurable: true
				});
			}
			/**
			* Factory method to create a new React element. This no longer adheres to
			* the class pattern, so do not use new to call it. Also, instanceof check
			* will not work. Instead test $$typeof field against Symbol.for('react.element') to check
			* if something is a React Element.
			*
			* @param {*} type
			* @param {*} props
			* @param {*} key
			* @param {string|object} ref
			* @param {*} owner
			* @param {*} self A *temporary* helper to detect places where `this` is
			* different from the `owner` when React.createElement is called, so that we
			* can warn. We want to get rid of owner and replace string `ref`s with arrow
			* functions, and as long as `this` and owner are the same, there will be no
			* change in behavior.
			* @param {*} source An annotation object (added by a transpiler or otherwise)
			* indicating filename, line number, and/or other information.
			* @internal
			*/
			var ReactElement = function(type, key, ref, self, source, owner, props) {
				var element = {
					$$typeof: REACT_ELEMENT_TYPE,
					type,
					key,
					ref,
					props,
					_owner: owner
				};
				element._store = {};
				Object.defineProperty(element._store, "validated", {
					configurable: false,
					enumerable: false,
					writable: true,
					value: false
				});
				Object.defineProperty(element, "_self", {
					configurable: false,
					enumerable: false,
					writable: false,
					value: self
				});
				Object.defineProperty(element, "_source", {
					configurable: false,
					enumerable: false,
					writable: false,
					value: source
				});
				if (Object.freeze) {
					Object.freeze(element.props);
					Object.freeze(element);
				}
				return element;
			};
			/**
			* https://github.com/reactjs/rfcs/pull/107
			* @param {*} type
			* @param {object} props
			* @param {string} key
			*/
			function jsxDEV(type, config, maybeKey, source, self) {
				var propName;
				var props = {};
				var key = null;
				var ref = null;
				if (maybeKey !== void 0) {
					checkKeyStringCoercion(maybeKey);
					key = "" + maybeKey;
				}
				if (hasValidKey(config)) {
					checkKeyStringCoercion(config.key);
					key = "" + config.key;
				}
				if (hasValidRef(config)) {
					ref = config.ref;
					warnIfStringRefCannotBeAutoConverted(config, self);
				}
				for (propName in config) if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS.hasOwnProperty(propName)) props[propName] = config[propName];
				if (type && type.defaultProps) {
					var defaultProps = type.defaultProps;
					for (propName in defaultProps) if (props[propName] === void 0) props[propName] = defaultProps[propName];
				}
				if (key || ref) {
					var displayName = typeof type === "function" ? type.displayName || type.name || "Unknown" : type;
					if (key) defineKeyPropWarningGetter(props, displayName);
					if (ref) defineRefPropWarningGetter(props, displayName);
				}
				return ReactElement(type, key, ref, self, source, ReactCurrentOwner.current, props);
			}
			var ReactCurrentOwner$1 = ReactSharedInternals.ReactCurrentOwner;
			var ReactDebugCurrentFrame$1 = ReactSharedInternals.ReactDebugCurrentFrame;
			function setCurrentlyValidatingElement$1(element) {
				if (element) {
					var owner = element._owner;
					var stack = describeUnknownElementTypeFrameInDEV(element.type, element._source, owner ? owner.type : null);
					ReactDebugCurrentFrame$1.setExtraStackFrame(stack);
				} else ReactDebugCurrentFrame$1.setExtraStackFrame(null);
			}
			var propTypesMisspellWarningShown = false;
			/**
			* Verifies the object is a ReactElement.
			* See https://reactjs.org/docs/react-api.html#isvalidelement
			* @param {?object} object
			* @return {boolean} True if `object` is a ReactElement.
			* @final
			*/
			function isValidElement(object) {
				return typeof object === "object" && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
			}
			function getDeclarationErrorAddendum() {
				if (ReactCurrentOwner$1.current) {
					var name = getComponentNameFromType(ReactCurrentOwner$1.current.type);
					if (name) return "\n\nCheck the render method of `" + name + "`.";
				}
				return "";
			}
			function getSourceInfoErrorAddendum(source) {
				if (source !== void 0) {
					var fileName = source.fileName.replace(/^.*[\\\/]/, "");
					var lineNumber = source.lineNumber;
					return "\n\nCheck your code at " + fileName + ":" + lineNumber + ".";
				}
				return "";
			}
			/**
			* Warn if there's no key explicitly set on dynamic arrays of children or
			* object keys are not valid. This allows us to keep track of children between
			* updates.
			*/
			var ownerHasKeyUseWarning = {};
			function getCurrentComponentErrorInfo(parentType) {
				var info = getDeclarationErrorAddendum();
				if (!info) {
					var parentName = typeof parentType === "string" ? parentType : parentType.displayName || parentType.name;
					if (parentName) info = "\n\nCheck the top-level render call using <" + parentName + ">.";
				}
				return info;
			}
			/**
			* Warn if the element doesn't have an explicit key assigned to it.
			* This element is in an array. The array could grow and shrink or be
			* reordered. All children that haven't already been validated are required to
			* have a "key" property assigned to it. Error statuses are cached so a warning
			* will only be shown once.
			*
			* @internal
			* @param {ReactElement} element Element that requires a key.
			* @param {*} parentType element's parent's type.
			*/
			function validateExplicitKey(element, parentType) {
				if (!element._store || element._store.validated || element.key != null) return;
				element._store.validated = true;
				var currentComponentErrorInfo = getCurrentComponentErrorInfo(parentType);
				if (ownerHasKeyUseWarning[currentComponentErrorInfo]) return;
				ownerHasKeyUseWarning[currentComponentErrorInfo] = true;
				var childOwner = "";
				if (element && element._owner && element._owner !== ReactCurrentOwner$1.current) childOwner = " It was passed a child from " + getComponentNameFromType(element._owner.type) + ".";
				setCurrentlyValidatingElement$1(element);
				error("Each child in a list should have a unique \"key\" prop.%s%s See https://reactjs.org/link/warning-keys for more information.", currentComponentErrorInfo, childOwner);
				setCurrentlyValidatingElement$1(null);
			}
			/**
			* Ensure that every element either is passed in a static location, in an
			* array with an explicit keys property defined, or in an object literal
			* with valid key property.
			*
			* @internal
			* @param {ReactNode} node Statically passed child of any type.
			* @param {*} parentType node's parent's type.
			*/
			function validateChildKeys(node, parentType) {
				if (typeof node !== "object") return;
				if (isArray(node)) for (var i = 0; i < node.length; i++) {
					var child = node[i];
					if (isValidElement(child)) validateExplicitKey(child, parentType);
				}
				else if (isValidElement(node)) {
					if (node._store) node._store.validated = true;
				} else if (node) {
					var iteratorFn = getIteratorFn(node);
					if (typeof iteratorFn === "function") {
						if (iteratorFn !== node.entries) {
							var iterator = iteratorFn.call(node);
							var step;
							while (!(step = iterator.next()).done) if (isValidElement(step.value)) validateExplicitKey(step.value, parentType);
						}
					}
				}
			}
			/**
			* Given an element, validate that its props follow the propTypes definition,
			* provided by the type.
			*
			* @param {ReactElement} element
			*/
			function validatePropTypes(element) {
				var type = element.type;
				if (type === null || type === void 0 || typeof type === "string") return;
				var propTypes;
				if (typeof type === "function") propTypes = type.propTypes;
				else if (typeof type === "object" && (type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_MEMO_TYPE)) propTypes = type.propTypes;
				else return;
				if (propTypes) {
					var name = getComponentNameFromType(type);
					checkPropTypes(propTypes, element.props, "prop", name, element);
				} else if (type.PropTypes !== void 0 && !propTypesMisspellWarningShown) {
					propTypesMisspellWarningShown = true;
					error("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", getComponentNameFromType(type) || "Unknown");
				}
				if (typeof type.getDefaultProps === "function" && !type.getDefaultProps.isReactClassApproved) error("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
			}
			/**
			* Given a fragment, validate that it can only be provided with fragment props
			* @param {ReactElement} fragment
			*/
			function validateFragmentProps(fragment) {
				var keys = Object.keys(fragment.props);
				for (var i = 0; i < keys.length; i++) {
					var key = keys[i];
					if (key !== "children" && key !== "key") {
						setCurrentlyValidatingElement$1(fragment);
						error("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", key);
						setCurrentlyValidatingElement$1(null);
						break;
					}
				}
				if (fragment.ref !== null) {
					setCurrentlyValidatingElement$1(fragment);
					error("Invalid attribute `ref` supplied to `React.Fragment`.");
					setCurrentlyValidatingElement$1(null);
				}
			}
			var didWarnAboutKeySpread = {};
			function jsxWithValidation(type, props, key, isStaticChildren, source, self) {
				var validType = isValidElementType(type);
				if (!validType) {
					var info = "";
					if (type === void 0 || typeof type === "object" && type !== null && Object.keys(type).length === 0) info += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.";
					var sourceInfo = getSourceInfoErrorAddendum(source);
					if (sourceInfo) info += sourceInfo;
					else info += getDeclarationErrorAddendum();
					var typeString;
					if (type === null) typeString = "null";
					else if (isArray(type)) typeString = "array";
					else if (type !== void 0 && type.$$typeof === REACT_ELEMENT_TYPE) {
						typeString = "<" + (getComponentNameFromType(type.type) || "Unknown") + " />";
						info = " Did you accidentally export a JSX literal instead of a component?";
					} else typeString = typeof type;
					error("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", typeString, info);
				}
				var element = jsxDEV(type, props, key, source, self);
				if (element == null) return element;
				if (validType) {
					var children = props.children;
					if (children !== void 0) if (isStaticChildren) if (isArray(children)) {
						for (var i = 0; i < children.length; i++) validateChildKeys(children[i], type);
						if (Object.freeze) Object.freeze(children);
					} else error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
					else validateChildKeys(children, type);
				}
				if (hasOwnProperty.call(props, "key")) {
					var componentName = getComponentNameFromType(type);
					var keys = Object.keys(props).filter(function(k) {
						return k !== "key";
					});
					var beforeExample = keys.length > 0 ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
					if (!didWarnAboutKeySpread[componentName + beforeExample]) {
						error("A props object containing a \"key\" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />", beforeExample, componentName, keys.length > 0 ? "{" + keys.join(": ..., ") + ": ...}" : "{}", componentName);
						didWarnAboutKeySpread[componentName + beforeExample] = true;
					}
				}
				if (type === REACT_FRAGMENT_TYPE) validateFragmentProps(element);
				else validatePropTypes(element);
				return element;
			}
			function jsxWithValidationStatic(type, props, key) {
				return jsxWithValidation(type, props, key, true);
			}
			function jsxWithValidationDynamic(type, props, key) {
				return jsxWithValidation(type, props, key, false);
			}
			var jsx = jsxWithValidationDynamic;
			var jsxs = jsxWithValidationStatic;
			exports.Fragment = REACT_FRAGMENT_TYPE;
			exports.jsx = jsx;
			exports.jsxs = jsxs;
		})();
	}));

//#endregion
//#region node_modules/react/jsx-runtime.js
	var require_jsx_runtime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = require_react_jsx_runtime_development();
	}));

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
	var import_jsx_runtime = require_jsx_runtime();
	var QueryClientContext = react.createContext(void 0);
	var useQueryClient = (queryClient) => {
		const client = react.useContext(QueryClientContext);
		if (queryClient) return queryClient;
		if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
		return client;
	};
	var QueryClientProvider = ({ client, children }) => {
		react.useEffect(() => {
			client.mount();
			return () => {
				client.unmount();
			};
		}, [client]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
			value: client,
			children
		});
	};

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
	var IsRestoringContext = react.createContext(false);
	var useIsRestoring = () => react.useContext(IsRestoringContext);
	var IsRestoringProvider = IsRestoringContext.Provider;

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
	function createValue() {
		let isReset = false;
		return {
			clearReset: () => {
				isReset = false;
			},
			reset: () => {
				isReset = true;
			},
			isReset: () => {
				return isReset;
			}
		};
	}
	var QueryErrorResetBoundaryContext = react.createContext(createValue());
	var useQueryErrorResetBoundary = () => react.useContext(QueryErrorResetBoundaryContext);

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
	var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary) => {
		if (options.suspense || options.throwOnError || options.experimental_prefetchInRender) {
			if (!errorResetBoundary.isReset()) options.retryOnMount = false;
		}
	};
	var useClearResetErrorBoundary = (errorResetBoundary) => {
		react.useEffect(() => {
			errorResetBoundary.clearReset();
		}, [errorResetBoundary]);
	};
	var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
		return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
	};

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/suspense.js
	var ensureSuspenseTimers = (defaultedOptions) => {
		if (defaultedOptions.suspense) {
			const MIN_SUSPENSE_TIME_MS = 1e3;
			const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
			const originalStaleTime = defaultedOptions.staleTime;
			defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
			if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
		}
	};
	var willFetch = (result, isRestoring) => result.isLoading && result.isFetching && !isRestoring;
	var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
	var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
		errorResetBoundary.clearReset();
	});

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
	function useBaseQuery(options, Observer, queryClient) {
		if (typeof options !== "object" || Array.isArray(options)) throw new Error("Bad argument type. Starting with v5, only the \"Object\" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object");
		const isRestoring = useIsRestoring();
		const errorResetBoundary = useQueryErrorResetBoundary();
		const client = useQueryClient(queryClient);
		const defaultedOptions = client.defaultQueryOptions(options);
		client.getDefaultOptions().queries?._experimental_beforeQuery?.(defaultedOptions);
		if (!defaultedOptions.queryFn) console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : "optimistic";
		ensureSuspenseTimers(defaultedOptions);
		ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary);
		useClearResetErrorBoundary(errorResetBoundary);
		const isNewCacheEntry = !client.getQueryCache().get(defaultedOptions.queryHash);
		const [observer] = react.useState(() => new Observer(client, defaultedOptions));
		const result = observer.getOptimisticResult(defaultedOptions);
		const shouldSubscribe = !isRestoring && options.subscribed !== false;
		react.useSyncExternalStore(react.useCallback((onStoreChange) => {
			const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
			observer.updateResult();
			return unsubscribe;
		}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
		react.useEffect(() => {
			observer.setOptions(defaultedOptions);
		}, [defaultedOptions, observer]);
		if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
		if (getHasError({
			result,
			errorResetBoundary,
			throwOnError: defaultedOptions.throwOnError,
			query: client.getQueryCache().get(defaultedOptions.queryHash),
			suspense: defaultedOptions.suspense
		})) throw result.error;
		client.getDefaultOptions().queries?._experimental_afterQuery?.(defaultedOptions, result);
		if (defaultedOptions.experimental_prefetchInRender && !isServer && willFetch(result, isRestoring)) (isNewCacheEntry ? fetchOptimistic(defaultedOptions, observer, errorResetBoundary) : client.getQueryCache().get(defaultedOptions.queryHash)?.promise)?.catch(noop).finally(() => {
			observer.updateResult();
		});
		return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
	}

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQuery.js
	function useQuery(options, queryClient) {
		return useBaseQuery(options, QueryObserver, queryClient);
	}

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutationState.js
	function useIsMutating(filters, queryClient) {
		const client = useQueryClient(queryClient);
		return useMutationState({ filters: {
			...filters,
			status: "pending"
		} }, client).length;
	}
	function getResult(mutationCache, options) {
		return mutationCache.findAll(options.filters).map((mutation) => options.select ? options.select(mutation) : mutation.state);
	}
	function useMutationState(options = {}, queryClient) {
		const mutationCache = useQueryClient(queryClient).getMutationCache();
		const optionsRef = react.useRef(options);
		const result = react.useRef(null);
		if (result.current === null) result.current = getResult(mutationCache, options);
		react.useEffect(() => {
			optionsRef.current = options;
		});
		return react.useSyncExternalStore(react.useCallback((onStoreChange) => mutationCache.subscribe(() => {
			const nextResult = replaceEqualDeep(result.current, getResult(mutationCache, optionsRef.current));
			if (result.current !== nextResult) {
				result.current = nextResult;
				notifyManager.schedule(onStoreChange);
			}
		}), [mutationCache]), () => result.current, () => result.current);
	}

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutation.js
	function useMutation(options, queryClient) {
		const client = useQueryClient(queryClient);
		const [observer] = react.useState(() => new MutationObserver(client, options));
		react.useEffect(() => {
			observer.setOptions(options);
		}, [observer, options]);
		const result = react.useSyncExternalStore(react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
		const mutate = react.useCallback((variables, mutateOptions) => {
			observer.mutate(variables, mutateOptions).catch(noop);
		}, [observer]);
		if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
		return {
			...result,
			mutate,
			mutateAsync: result.mutate
		};
	}

//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js
	function useInfiniteQuery(options, queryClient) {
		return useBaseQuery(options, InfiniteQueryObserver, queryClient);
	}

//#endregion
//#region packages/packages/libs/query/src/index.ts
	var src_exports = /* @__PURE__ */ __exportAll({
		QueryClient: () => QueryClient,
		QueryClientProvider: () => QueryClientProvider,
		createQueryClient: () => createQueryClient,
		getQueryClient: () => getQueryClient,
		useInfiniteQuery: () => useInfiniteQuery,
		useIsMutating: () => useIsMutating,
		useMutation: () => useMutation,
		useQuery: () => useQuery,
		useQueryClient: () => useQueryClient
	});
	var queryClient;
	function getQueryClient() {
		if (!queryClient) throw new Error("Query client is not created yet.");
		return queryClient;
	}
	function createQueryClient() {
		if (queryClient) throw new Error("Query client is already created.");
		queryClient = new QueryClient({ defaultOptions: { queries: {
			refetchOnWindowFocus: false,
			refetchOnReconnect: false
		} } });
		return queryClient;
	}

//#endregion
//#region \0elementor-package-library-entry
	(window.elementorV2 = window.elementorV2 || {}).query = src_exports;

//#endregion
})(React);
window.elementorV2.query?.init?.();
//# sourceMappingURL=query.js.map